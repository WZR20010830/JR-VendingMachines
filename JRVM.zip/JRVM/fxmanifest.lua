fx_version 'cerulean' 

lua54 'yes'

games {'gta5'}  

this_is_a_map 'yes'  

Author 'Umidissimo' 

description 'JR_VendingMachines'  