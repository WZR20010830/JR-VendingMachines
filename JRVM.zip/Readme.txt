Grazie per aver scaricato la nostra mappa!
Per eventuali problemi contattaci
umidojj & Riccardo#1958
https://discord.gg/sAdD6dQ2XF

-----INSTALLATION INSTRUCTION-----

FiveM

1)Go to your server's resources folder

2)Drag and drop the JRVM folder here

3)Open to the server.cfg file and add

    start JRVM

4)Start your server and enjoy!